function myBirthYearFunc() {    
    console.log("I was born in " + 1980);
}
// Console log states I was born in 1980


function myBirthYearFunc(birthYearInput) {    
    console.log("I was born in " + 1980);
}
// Console log States I was born in 1980

function add(num1, num2) {    
    console.log("Summing Numbers!");    
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);    
    var sum = num1 + num2;    
    console.log(sum);
}
//Console log states Summing Numbers
//Console log states num1 is: ______(Num1 = some number)        
//Console log states num2 is: ______(Num2 = some number)   
//Console log states sum